<?php
include dirname(__DIR__) . '/koneksi.php';

$namakelas  = $_POST['namakelas'];
$tingkat    = $_POST['tingkat'];
$tahunajaran = $_POST['tahunajaran'];
$idguru     = $_POST['idguru'] ?: 'NULL';
$idsiswa    = $_POST['idsiswa'] ?: 'NULL';
$idruang    = $_POST['idruang'] ?: 'NULL';

$query = "INSERT INTO datakelas (namakelas, tingkat, tahunajaran, idguru, idsiswa, idruang) 
          VALUES ('$namakelas', '$tingkat', '$tahunajaran', $idguru, $idsiswa, $idruang)";

mysqli_query($koneksi, $query);

header("location:tampil.php");