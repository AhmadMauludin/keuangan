<?php
include dirname(__DIR__) . '/koneksi.php';

$id         = $_POST['id'];
$namakelas  = $_POST['namakelas'];
$tingkat    = $_POST['tingkat'];
$tahunajaran = $_POST['tahunajaran'];
$idguru     = $_POST['idguru'] ?: 'NULL';
$idsiswa    = $_POST['idsiswa'] ?: 'NULL';
$idruang    = $_POST['idruang'] ?: 'NULL';

$query = "UPDATE datakelas SET
          namakelas='$namakelas',
          tingkat='$tingkat',
          tahunajaran='$tahunajaran',
          idguru=$idguru,
          idsiswa=$idsiswa,
          idruang=$idruang
          WHERE id_kelas='$id'";

mysqli_query($koneksi, $query);
header("location:tampil.php");